<?php
	$MESS["test_module_MODULE_NAME"] = "Модуль загрузки в каталог";
	$MESS["test_module_MODULE_TAB_MAIN"] = "Основное";
	$MESS["test_module_MODULE_TAB_EDIT"] = "Дополнительно";
?>