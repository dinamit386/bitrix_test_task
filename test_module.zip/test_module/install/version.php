<?
$arModuleVersion = array(
"VERSION" => "0.0.1",
"VERSION_DATE" => "2021-02-16");
?>